import React from 'react'


const ServiceSection = () => {



  return (

    <div className="my-quality-main" id="quality">
      <div className="container">

        <div className="row pt-5 pb-5 ps-2 ">
          <div className="col-md-12 ">
            <h1 className="text-center pt-5 pb-4 quality-section-heading">My Quality Services</h1>
            <p className="text-white text-center quality-section-para">We put your ideas and thus your wishes in the
              form
              of a unique web project that inspires you
              and you customers.</p>
          </div>
        </div>

        <div className="row d-flex justify-content-evenly mt-md-1 mt-sm-5 ps-3 ps-md-0 row-border mb-4 mb-md-0 ">
          <div className="col-md-4 text-white ">
            <h3 className="pt-md-5 pb-md-5 ps-md-3 pe-md-3">01 Branding Design</h3>
          </div>
          <div className="col-md-7 text-light  fs-5 fw-light">
            <p className="pt-md-5 pb-md-5 ps-md-3 pe-md-3 pt-sm-2 pe-sm-2 table-content-para">I break down complex user
              experinece problems to create integritiy focussed
              solutions
              that connect billions of people</p>
          </div>
        </div>

        <div className="row d-flex justify-content-evenly mt-md-1 mt-sm-5 ps-3 ps-md-0 row-border mb-4 mb-md-0 ">
          <div className="col-md-4 text-white ">
            <h3 className="pt-md-5 pb-md-5 ps-md-3 pe-md-3">02 Web Design</h3>
          </div>
          <div className="col-md-7 text-light  fs-5 fw-light">
            <p className="pt-md-5 pb-md-5 ps-md-3 pe-md-3 pt-sm-2 pe-sm-2 table-content-para">I break down complex user
              experinece problems to create integritiy focussed
              solutions
              that connect billions of people</p>
          </div>
        </div>

        <div className="row d-flex justify-content-evenly mt-md-1 mt-sm-5 ps-3 ps-md-0 row-border mb-4 mb-md-0 ">
          <div className="col-md-4 text-white ">
            <h3 className="pt-md-5 pb-md-5 ps-md-3 pe-md-3">03 UI/UX Design</h3>
          </div>
          <div className="col-md-7 text-light  fs-5 fw-light">
            <p className="pt-md-5 pb-md-5 ps-md-3 pe-md-3 pt-sm-2 pe-sm-2 table-content-para">I break down complex user
              experinece problems to create integritiy focussed
              solutions
              that connect billions of people</p>
          </div>
        </div>

        <div className="row d-flex justify-content-evenly mt-md-1 mt-sm-5 ps-3 ps-md-0 mb-md-0 ">
          <div className="col-md-4 text-white ">
            <h3 className="pt-md-5 pb-md-5 ps-md-3 pe-md-3">04 Graphic Design</h3>
          </div>
          <div className="col-md-7 text-light  fs-5 fw-light">
            <p className="pt-md-5 pb-md-5 ps-md-3 pe-md-3 pt-sm-2 pe-sm-2 table-content-para">I break down complex user
              experinece problems to create integritiy focussed
              solutions
              that connect billions of people</p>
          </div>
        </div>






      </div>
    </div>
  )
}

export default ServiceSection