import "bootstrap/dist/css/bootstrap.min.css"
import "bootstrap/dist/js/bootstrap.bundle.min.js"
import './App.css'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Home from './components/Home'

import Header from './components/Header'
import Footer from './components/Footer'
import Services from "./components/Services"
import Works from "./components/Works"
import Resume from "./components/Resume"
import Skills from "./components/Skills"
import Blog from "./components/Blog"
import Contact from "./components/Contact"
function App() {


  return (
    <>
      <BrowserRouter>
        <Header />
        <Routes>

          <Route path='/' element={<Home />} />
          <Route path="/services" element={<Services />} />
          <Route path='/works' element={< Works />} />
          <Route path="/resume" element={<Resume />} />
          <Route path='/skills' element={<Skills />} />
          <Route path="/blog" element={<Blog />} />
          <Route path='/contact' element={<Contact />} />



        </Routes>
        <Footer />
      </BrowserRouter>
    </>
  )
}

export default App
