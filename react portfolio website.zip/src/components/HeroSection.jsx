import React, { } from 'react'
import { useGlobalContext } from '../store/context'

const HeroSection = () => {

  const { name, image } = useGlobalContext();



  return (
    <div id="hero-section">
      <div className="container ">
        <div className="row d-flex justify-content-between ">

          <div className="col-lg-6 order-lg-1  order-md-1 order-sm-2 order-2">
            <h3 className="hero-section-subheading">I am {name} </h3>
            <h1 className="hero-section-heading">Full Stack Developer + <br /> Web Designer </h1>
            <p className="hero-section-para">I break down complex user experinece problems to create integritiy focussed
              solutions that connect billions of people</p>


            <div className="row hero-section-btn-container mt-5 gap-3 ">
              <div className="col-lg-5 col-xxl-4  col-md-4  d-flex justify-content-start align-items-center"><a href="#">
                <button className="hero-section-btn"> Download CV</button> </a>
              </div>
              <div className="col-lg-5 col-md-5 d-flex justify-content-between ">
                <div className="d-flex justify-content-start gap-2 icon-container">
                  <a href="#"> <i className="fa-brands fa-twitter "></i> </a>
                  <a href="#"> <i className="fa-solid fa-basketball "></i> </a>
                  <a href="#"> <i className="fa-brands fa-linkedin-in "></i> </a>
                  <a href="#"> <i className="fa-brands fa-github-alt "></i> </a>

                </div>
              </div>
            </div>
          </div>

          <div className="col-lg-6 order-lg-2 order-md-2 order-sm-1 order-1 hero-section-image">
            <img src={image} className="img-fluid img-border" width="100%" height="80%" />
          </div>

        </div>

        <div className="row  d-flex justify-content-between">
          <div className="col-lg-3 col-md-6  p-3  d-flex justify-content-evenly hero-section-4box">
            <h1 className="year-experience  text-white p-2 ">14+</h1>
            <p className="text-white p-2 box4-para text-start">Years Of <br />Experinece</p>
          </div>

          <div className="col-lg-3 col-md-6  p-3 d-flex justify-content-evenly">
            <h1 className="year-experience  text-white p-2">50+</h1>
            <p className="text-white p-2  box4-para text-start">Projects <br />Completed</p>
          </div>

          <div className="col-lg-3 col-md-6  p-3 d-flex justify-content-evenly">
            <h1 className="year-experience  text-white p-2 ">1.5k</h1>
            <p className="text-white p-2 box4-para text-start">Happy <br />Clients</p>
          </div>

          <div className="col-lg-3 col-md-6  p-3 d-flex justify-content-evenly">
            <h1 className="year-experience  text-white  p-2">14+</h1>
            <p className="text-white p-2 box4-para text-start">Years Of <br />Experinece</p>
          </div>

        </div>






      </div>
    </div>
  )
}

export default HeroSection