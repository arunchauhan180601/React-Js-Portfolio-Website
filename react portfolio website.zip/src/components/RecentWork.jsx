

import React, { useState } from 'react';

const RecentWork = () => {
  const [selectedCategory, setSelectedCategory] = useState('all');

  const works = [
    {
      id: 1,
      category: 'ui-ux',
      imgSrc: 'Images/my-recent-work-1.jpg',
      title: 'Deloitte',
      description: 'Project was about precision and information'
    },
    {
      id: 2,
      category: 'branding',
      imgSrc: 'Images/my-recent-work-2.jpg',
      title: 'New Age',
      description: 'Project was about precision and information'
    },
    {
      id: 3,
      category: 'ui-ux',
      imgSrc: 'Images/my-recent-work-3.jpg',
      title: 'Social Media',
      description: 'Project was about precision and information'
    },
    {
      id: 4,
      category: 'apps',
      imgSrc: 'Images/my-recent-work-4.jpg',
      title: 'Mochnix',
      description: 'Project was about precision and information'
    },
  ];

  const handleCategoryClick = (category) => {
    setSelectedCategory(category);
  };

  const filteredWorks = selectedCategory === 'all'
    ? works
    : works.filter(work => work.category === selectedCategory);

  return (
    <div className="my-recent-main" id="works">
      <div className="container pb-5 pt-5">
        <div className="row pt-5 pb-5 ps-2">
          <div className="col-md-12">
            <h1 className="text-center pt-5 pb-2 recent-section-heading">My Recent Works</h1>
            <p className="text-white text-center recent-section-para">We put your ideas and thus your wishes in the form of a unique web project that inspires you and your customers.</p>
          </div>
        </div>

        <div className="row ps-2 pe-2 d-flex justify-content-center pt-3 pb-3 tabs">
          <div
            className="col-md-2 col-lg-1 me-1 col-2 recent-work-btn text-white border text-center rounded-pill pt-2 pb-2"
            onClick={() => handleCategoryClick('all')}
          >
            All
          </div>
          <div
            className="col-md-2 col-lg-1 me-1 col-2 recent-work-btn text-white border text-center rounded-pill pt-2 pb-2"
            onClick={() => handleCategoryClick('ui-ux')}
          >
            UI/UX
          </div>
          <div
            className="col-md-2 col-lg-1 me-1 col-3 recent-work-btn text-white border text-center rounded-pill pt-2 pb-2"
            onClick={() => handleCategoryClick('branding')}
          >
            Branding
          </div>
          <div
            className="col-md-2 col-lg-1 me-1 col-2 recent-work-btn text-white border text-center rounded-pill pt-2 pb-2"
            onClick={() => handleCategoryClick('apps')}
          >
            Apps
          </div>
        </div>

        <div className="row d-flex justify-content-evenly pt-3 pb-5">
          {filteredWorks.map(work => (
            <div key={work.id} className="col-md-5 pt-5 position-relative recent-work-box images" data-category1={work.category}>
              <img src={work.imgSrc} className="recent-work-img img-fluid" alt={`my-recent-work-${work.id}`} />
              <div className="start-0 recent-work-hover-content text-white">
                <h1 className="p-3">{work.title}</h1>
                <p className="ps-3">{work.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default RecentWork;
