import React from 'react'

const Footer = () => {
  return (
    <div className="footer-main">
      <div className="container pt-5 pb-5">
        <div className="row">
          <div className="col-12  ">
            <div className="mx-auto d-flex justify-content-center mb-4">
              <img src="Images/logo.png" className="img-fluid " width="70px" />
            </div>

            <p className="text-center text-white">© 2024 All rights reserved by ThemeJunction</p>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Footer