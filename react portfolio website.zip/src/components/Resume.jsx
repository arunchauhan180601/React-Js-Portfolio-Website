import React from 'react'
import MyEducation from './MyEducation'

const Resume = () => {
  return (
    <MyEducation />
  )
}

export default Resume