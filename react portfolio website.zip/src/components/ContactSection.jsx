import React from 'react'

const ContactSection = () => {
  return (
    <div className="contact-main" id="contact">
      <div className="container pt-5 pb-5 ">
        <div className="row pt-5 pb-5">

          <div className="col-lg-6 form-bgcolor pt-3 pe-3  ps-3">
            <h1 className="contact-heading ps-3 pe-3 pt-3 pb-3">Let's work together!</h1>
            <p className="contact-para ps-3 pe-3 text-white">I design and code beautifully simple things and i love what i do. Just simple like that!</p>

            <form className="ps-3 pe-3 pt-3 pb-3" action='https://formspree.io/f/mpzveoaz' method='post'>
              <div className="mb-3">
                <label htmlFor="exampleInputEmail1" className="form-label text-white">Enter Your Name</label>
                <input type="text" name='FirstName' className="form-control " id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Your Name" required autoComplete='off' />

              </div>

              <div className="mb-3">
                <label htmlFor="exampleInputPassword1" className="form-label text-white">Email Address</label>
                <input type="email" name='Email' className="form-control" id="exampleInputPassword1" placeholder="Enter Your Email" required autoComplete='off' />
              </div>

              <div className="mb-3">
                <label htmlFor="exampleInputEmail1" className="form-label text-white">Phone Number</label>
                <input type="number" name='PhoneNumber' className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Your Phone Number" required autoComplete='off' />
              </div>

              <div className="mb-3">
                <label htmlFor="exampleInputEmail1" className="form-label text-white">Message</label>
                <textarea className="form-control" placeholder="Leave a comment here" id="floatingTextarea2" style={{ height: "100px" }}></textarea>

              </div>


              <button type="submit" className="btn form-btn-bgcolor mt-2 mb-4">Submit</button>
            </form>

          </div>

          <div className="col-lg-6 mt-md-5 mt-sm-5 mt-5 ps-3 pe-3 d-flex flex-direction-column justify-content-md-center align-items-center justify-content-sm-start">

            <div className="form-right-content-main ps-3 pe-3 ">
              <div className=" gap-3  pt-3 pb-3 ps-2 pe-3  form-right-content-box" >
                <p><i className="fa-solid fa-phone-volume icon-fontsize"></i></p>
                <h5 className=" contact-right-content "> Phone <br />  +7572987654</h5>
              </div>

              <div className="gap-3  pt-3 pb-3 ps-2 form-right-content-box">
                <p><i className="fa-regular fa-envelope icon-fontsize"></i></p>
                <h5 className=" contact-right-content">Email <br />arunchauhan3303@gmail.com</h5>
              </div>


              <div className=" gap-3 pt-3 pb-3 ps-2 pe-3 form-right-content-box">
                <p><i className="fa-solid fa-location-dot icon-fontsize"></i></p>
                <h5 className=" contact-right-content">Address <br /> Warne Park Street Pine,
                  FL 33157, New York</h5>
              </div>

            </div>

          </div>
        </div>
      </div>
    </div>
  )
}

export default ContactSection