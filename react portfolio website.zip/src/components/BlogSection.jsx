import React from 'react'

const BlogSection = () => {
  return (
    <div className="my-blog-main pt-1 pb-5" id="blog">
      <div className="container pb-5 pt-5">

        <div className="row pt-5 pb-5 ps-2 ">
          <div className="col-md-12 ">
            <h1 className="text-center pt-5 pb-2 blog-section-heading">Recent Blogs</h1>
            <p className="text-white text-center recent-section-para">We put your ideas and thus your wishes in the form of a unique web project that inspires you and you customers. </p>
          </div>
        </div>

        <div className="row mt-3 mb-3d-flex gap-4 justify-content-evenly overflow-hidden">
          <div className="col-xxl-3 col-md-5 blog-image-div position-relative ">
            <img className="img-fluid blog-image" src="Images/blog-1.jpg" width="100%" />
            <div className="blog-image-content-main">
              <p className="blog-image-content-para p-2 pb-1"> <i className="fa-solid fa-calendar-days"></i> Oct 01, 2022  <i className="fa-solid fa-calendar-days"></i> Comment (0)</p>
              <h5 className="text-white  pb-1 pb-1 ps-2">Top 10 Ui Ux Designers</h5>
            </div>
          </div>

          <div className="col-xxl-3 col-md-5 blog-image-div position-relative">
            <img className="img-fluid blog-image" src="Images/blog-2.jpg" width="100%" />
            <div className="blog-image-content-main">
              <p className="blog-image-content-para p-2 pb-1"> <i className="fa-solid fa-calendar-days"></i> Oct 01, 2022  <i className="fa-solid fa-calendar-days"></i> Comment (0)</p>
              <h5 className="text-white  pb-1 pb-1 ps-2">App Development Guides</h5>
            </div>
          </div>

          <div className="col-xxl-3 col-md-5 mt-md-5 mt-lg-5  mt-xxl-0  blog-image-div position-relative">
            <img className="img-fluid blog-image" src="Images/blog-3.jpg" width="100%" />
            <div className="blog-image-content-main">
              <p className="blog-image-content-para p-2 pb-1"> <i className="fa-solid fa-calendar-days"></i> Oct 01, 2022  <i className="fa-solid fa-calendar-days"></i> Comment (0)</p>
              <h5 className="text-white  pb-1 pb-1 ps-2">Learn Graphic Design Free</h5>
            </div>
          </div>
        </div>

      </div>
    </div>
  )
}

export default BlogSection