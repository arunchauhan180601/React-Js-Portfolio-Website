import React from 'react'

const MySkills = () => {

  return (
    <div className="my-skill-main" id="skill">
      <div className="container pb-5 pt-5">

        <div className="row pt-5 pb-5 ps-2 ">
          <div className="col-md-12 ">
            <h1 className="text-center pt-5 pb-2 skill-section-heading">My Skills</h1>
            <p className="text-white text-center recent-section-para">We put your ideas and thus your wishes in the form of a unique web project that inspires you and you customers. </p>
          </div>
        </div>

        <div className="row d-flex justify-content-center">

          <div className="col-lg-2  col-md-3 col-sm-4 col-6 ">
            <div className="skill-box-border text-center pt-5 pb-4" >
              <h1 className="icon-size"><i className="fa-brands fa-css3-alt "></i></h1>
              <h4 className="text-white"> 92%</h4>
            </div>
            <p className="text-center text-white pt-3 pb-2">CSS</p>
          </div>

          <div className="col-lg-2 col-md-3 col-sm-4 col-6">
            <div className="skill-box-border text-center pt-5 pb-4">
              <h1 className="icon-size"><i className="fa-brands fa-react"></i></h1>
              <h4 className="text-white">80%</h4>
            </div>
            <p className="text-center text-white pt-3 pb-2">React</p>
          </div>

          <div className="col-lg-2 col-md-3 col-sm-4 col-6">
            <div className="skill-box-border text-center pt-5 pb-4">
              <h1 className="icon-size"><i className="fa-brands fa-node-js"></i></h1>
              <h4 className="text-white">92%</h4>
            </div>
            <p className="text-center text-white pt-3 pb-2">Javascript</p>
          </div>

          <div className="col-lg-2 col-md-3 col-sm-4 col-6">
            <div className="skill-box-border text-center pt-5 pb-4">
              <h1 className="icon-size"><i className="fa-brands fa-node-js"></i></h1>
              <h4 className="text-white">85%</h4>
            </div>
            <p className="text-center text-white pt-3 pb-2">Node Js</p>
          </div>

          <div className="col-lg-2 col-md-3 col-sm-4 col-6">
            <div className="skill-box-border text-center pt-5 pb-4">
              <h1 className="icon-size"><i className="fa-brands fa-html5"></i></h1>
              <h4 className="text-white">95%</h4>
            </div>
            <p className="text-center text-white pt-3 pb-2">HTML 5</p>
          </div>


          <div className="col-lg-2 col-md-3 col-sm-4 col-6">
            <div className="skill-box-border text-center pt-5 pb-4">
              <h1 className="icon-size"><i className="fa-brands fa-bootstrap"></i></h1>
              <h4 className="text-white">90%</h4>
            </div>
            <p className="text-center text-white pt-3 pb-2">Bootstrap</p>
          </div>

        </div>
      </div>
    </div>
  )
}

export default MySkills