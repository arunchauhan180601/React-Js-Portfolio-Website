import React from 'react'
import BlogSection from './BlogSection'

const Blog = () => {
  return (
    <BlogSection />

  )
}

export default Blog