import React from 'react'
import MySkills from './MySkills'

const Skills = () => {
  return (
    <div className="mt-5">

      <MySkills />

    </div>
  )
}

export default Skills