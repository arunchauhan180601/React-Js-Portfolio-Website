import { createContext, useContext, useReducer } from "react";



const AppContext = createContext();

const initial_value = {
  name: "",
  image: ""
}

const reducer = (state, action) => {

  if (action.type === "HOME_UPDATE") {
    return {
      ...state,
      name: action.payload.name,
      image: action.payload.image,
    }
  }
  else if (action.type === "SERVICE_UPDATE") {
    return {
      ...state,
      name: action.payload.name,
      image: action.payload.image,
    }
  }

  return state;
}

const AppProvider = ({ children }) => {


  const [state, dispatch] = useReducer(reducer, initial_value);

  const updateHomePage = () => {
    return dispatch({
      type: "HOME_UPDATE",
      payload: {
        name: "Arun",
        image: "/Images/me.png"
      }
    })
  }

  const updateServicePage = () => {
    return dispatch({
      type: "SERVICE_UPDATE",
      payload: {
        name: "Arun",
        image: "/Images/arun2.jpg"
      }
    })
  }

  return <AppContext.Provider value={{ ...state, updateHomePage, updateServicePage }}>{children}</AppContext.Provider>
}


const useGlobalContext = () => {
  return useContext(AppContext)
}

export { AppContext, AppProvider, useGlobalContext }