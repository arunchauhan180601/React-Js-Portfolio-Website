import React from 'react'
import ContactSection from './ContactSection'

const Contact = () => {
  return (
    <div className="mt-5">
      <ContactSection />
    </div>
  )
}

export default Contact