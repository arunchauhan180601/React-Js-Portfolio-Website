import React, { useEffect } from 'react'
import HeroSection from './HeroSection'
import ServiceSection from './ServiceSection'
import { useGlobalContext } from '../store/context'

const Services = () => {

  const { updateServicePage } = useGlobalContext();

  useEffect(() => {
    updateServicePage();
  }, [])

  return (
    <>
      <HeroSection />
      <ServiceSection />
    </>
  )
}

export default Services