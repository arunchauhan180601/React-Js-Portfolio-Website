import React, { useEffect } from 'react'
import HeroSection from './HeroSection'
import { useGlobalContext } from '../store/context'
import ServiceSection from './ServiceSection';
import RecentWork from './RecentWork';
import MyEducation from './MyEducation';
import MySkills from './MySkills';
import BlogSection from './BlogSection';
import ContactSection from './ContactSection';

const Home = () => {

  const { updateHomePage } = useGlobalContext();

  useEffect(() => {

    updateHomePage()

  }, [])

  return (
    <>
      <HeroSection />
      <ServiceSection />
      <RecentWork />
      <MyEducation />
      <MySkills />
      <BlogSection />
      <ContactSection />
    </>


  )
}

export default Home