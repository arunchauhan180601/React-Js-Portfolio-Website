const MyEducation = () => {
  return (
    <>
      <div className="experience-education-section" id="resume">
        <div className="container pt-5 pe-5  ">
          <div className="row pt-5 pb-5 d-flex justify-content-between">
            <div className="col-md-6 pb-5">


              <h1 className="pt-3 pb-3 ps-2 pe-2 experience-heading ">My Experience</h1>


              <div className="ps-3 mt-5 pb-2  experience-box-main">
                <h4 className="pt-2 experience-box-h4-content">2022 - Present </h4>
                <h3 className="pt-2 text-white">Lead Developer</h3>
                <p className="pt-2 text-white">Blockdots, London</p>
              </div>

              <div className="ps-3 mt-4 pb-2  experience-box-main">
                <h4 className="pt-2 experience-box-h4-content">2021 - 2022  </h4>
                <h3 className="pt-2 text-white">FULL STACK WEB DEVELOPER</h3>
                <p className="pt-2 text-white">Parsons, The New School</p>
              </div>

              <div className="ps-3 mt-4 pb-2  experience-box-main">
                <h4 className="pt-2 experience-box-h4-content">2020 - 2021 </h4>
                <h3 className="pt-2 text-white">UI DESIGNER</h3>
                <p className="pt-2 text-white">House of Life, Leeds</p>
              </div>

              <div className="ps-3 mt-4 pb-2  experience-box-main">
                <h4 className="pt-2 experience-box-h4-content">2018 - 2020 </h4>
                <h3 className="pt-2 text-white">JUNIOR GRAPHICS DESIGNER</h3>
                <p className="pt-2 text-white">Theme Junction, Bursa</p>
              </div>

            </div>
            <div className="col-md-6 ">
              <h1 className="pt-3  pb-3 ps-2 pe-2 experience-heading ">My Education</h1>

              <div className="ps-3 mt-5 pb-2  experience-box-main">
                <h4 className="pt-2 experience-box-h4-content">2020 - 2023 </h4>
                <h3 className="pt-2 text-white">PROGRAMMING COURSE</h3>
                <p className="pt-2 text-white">Harverd University</p>
              </div>

              <div className="ps-3 mt-4 pb-2  experience-box-main">
                <h4 className="pt-2 experience-box-h4-content">2016 - 2020  </h4>
                <h3 className="pt-2 text-white">GRAPHIC DESIGN COURSE</h3>
                <p className="pt-2 text-white">University of Denmark</p>
              </div>

              <div className="ps-3 mt-4 pb-2  experience-box-main">
                <h4 className="pt-2 experience-box-h4-content">2012 - 2015 </h4>
                <h3 className="pt-2 text-white">WEB DESIGN COURSE</h3>
                <p className="pt-2 text-white">University of California</p>
              </div>

              <div className="ps-3 mt-4 pb-2  experience-box-main">
                <h4 className="pt-2 experience-box-h4-content">2010 - 2011 </h4>
                <h3 className="pt-2 text-white">DESIGN & TECHNOLOGY</h3>
                <p className="pt-2 text-white">Parsons, The New School</p>
              </div>


            </div>
          </div>
        </div>
      </div>
    </>
  )
}

export default MyEducation