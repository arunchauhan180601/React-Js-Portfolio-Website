import React from 'react'
import RecentWork from './RecentWork'

const Works = () => {
  return (
    <RecentWork />
  )
}

export default Works